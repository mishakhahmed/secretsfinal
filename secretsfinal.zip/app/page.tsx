import SecretsBangladeshApp from "@/components/secrets-bangladesh-app"

export default function Page() {
  return <SecretsBangladeshApp />
}
